const links = {
  home: '/',
  about: '/about',
  addons: '/addons',
  support: '/support',
};
export default links;
